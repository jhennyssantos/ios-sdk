//
//  EMVConnectiOS.h
//  EMVConnectiOS
//
//  Created by Carla Galdino Wanderley on 10/10/17.
//  Copyright © 2017 Carla Galdino Wanderley. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Bridging-Header.h"

//! Project version number for EMVConnectiOS.
FOUNDATION_EXPORT double EMVConnectiOSVersionNumber;

//! Project version string for EMVConnectiOS.
FOUNDATION_EXPORT const unsigned char EMVConnectiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EMVConnectiOS/PublicHeader.h>


